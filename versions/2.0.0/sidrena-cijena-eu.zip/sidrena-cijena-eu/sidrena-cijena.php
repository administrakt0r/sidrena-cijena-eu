<?php
/**
 * Plugin Name:       Sidrena Cijena EU
 * Plugin URI:        https://github.com/administrakt0r/sidrena-cijena-eu
 * Description:       Records, displays, validates and publishes the Croatian anchor price ("sidrena cijena"), the daily machine-readable price list and the 30-day lowest price for special forms of sale. A technical compliance aid, not legal advice.
 * Version:           2.0.0
 * Requires at least: 6.8
 * Requires PHP:      7.4
 * Author:            administrakt0r
 * Author URI:        https://github.com/administrakt0r
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sidrena-cijena-eu
 * Domain Path:       /languages
 *
 * @package SidrenaCijena
 */

defined( 'ABSPATH' ) || exit;

define( 'SIDRENA_CIJENA_VERSION', '2.0.0' );
define( 'SIDRENA_CIJENA_FILE', __FILE__ );
define( 'SIDRENA_CIJENA_DIR', plugin_dir_path( __FILE__ ) );
define( 'SIDRENA_CIJENA_URL', plugin_dir_url( __FILE__ ) );
define( 'SIDRENA_CIJENA_BASENAME', plugin_basename( __FILE__ ) );

require_once SIDRENA_CIJENA_DIR . 'src/Support/Autoloader.php';
require_once SIDRENA_CIJENA_DIR . 'src/Api/functions.php';
require_once SIDRENA_CIJENA_DIR . 'src/Api/global-functions.php';
\SidrenaCijena\Support\Autoloader::register();

register_activation_hook( __FILE__, array( 'SidrenaCijena\Support\Install', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'SidrenaCijena\Support\Deactivator', 'deactivate' ) );

/**
 * Load the plugin translations.
 *
 * Always loads the Croatian translation catalogue by default so the plugin
 * interface is 100% in Croatian on all sites, even if WordPress runs in English.
 *
 * @return void
 */
function sidrena_cijena_load_textdomain() {
	load_textdomain( 'sidrena-cijena-eu', SIDRENA_CIJENA_DIR . 'languages/sidrena-cijena-eu-hr.mo' );
}
add_action( 'plugins_loaded', 'sidrena_cijena_load_textdomain', 5 );
add_action( 'init', 'sidrena_cijena_load_textdomain', 1 );

/**
 * Declare WooCommerce compatibility before WooCommerce loads its features.
 *
 * The plugin keeps its own tables and never reads or writes orders, so High
 * Performance Order Storage changes nothing for it. Declaring it explicitly
 * keeps WooCommerce from flagging the plugin as untested/incompatible.
 *
 * @return void
 */
function sidrena_cijena_declare_woocommerce_compatibility() {
	if ( ! class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		return;
	}

	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', SIDRENA_CIJENA_FILE, true );
}

add_action( 'before_woocommerce_init', 'sidrena_cijena_declare_woocommerce_compatibility' );

add_action( 'plugins_loaded', array( 'SidrenaCijena\Plugin', 'boot' ), 20 );
